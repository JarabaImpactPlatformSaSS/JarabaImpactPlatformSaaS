-- ============================================================
-- ESQUEMA BASE DE DATOS NORMATIVA - COPILOTO ANDALUCÍA +ei
-- Sistema RAG para Modos Expertos (Tributario y Seguridad Social)
-- 
-- Requisitos:
-- - PostgreSQL 14+
-- - Extensión pgvector instalada
-- ============================================================

-- Habilitar extensión pgvector
CREATE EXTENSION IF NOT EXISTS vector;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================================
-- 1. TABLA PRINCIPAL DE DOCUMENTOS NORMATIVOS
-- ============================================================

CREATE TABLE IF NOT EXISTS normativa_documents (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    
    -- Identificación
    source VARCHAR(50) NOT NULL,          -- 'BOE', 'BOJA', 'AEAT', 'TGSS', 'SEPE'
    category VARCHAR(20) NOT NULL,        -- 'TAX', 'SS', 'SUBVENCION'
    subcategory VARCHAR(50),              -- 'IVA', 'IRPF', 'RETA', 'COTIZACION', etc.
    
    -- Contenido
    title TEXT NOT NULL,
    description TEXT,
    original_url TEXT,
    raw_content TEXT,                     -- Contenido original sin procesar
    
    -- Vigencia
    effective_date DATE,                  -- Fecha de entrada en vigor
    expiration_date DATE,                 -- NULL si sigue vigente
    last_verified TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    verified_by VARCHAR(100),
    
    -- Metadata
    version VARCHAR(20),
    tags TEXT[],                          -- Array de etiquetas
    priority INT DEFAULT 0,               -- Para ordenar en resultados
    
    -- Auditoría
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- Constraints
    CONSTRAINT valid_category CHECK (category IN ('TAX', 'SS', 'SUBVENCION')),
    CONSTRAINT valid_source CHECK (source IN ('BOE', 'BOJA', 'AEAT', 'TGSS', 'SEPE', 'MITES', 'SAE', 'MANUAL'))
);

-- Índices para búsquedas frecuentes
CREATE INDEX idx_normativa_category ON normativa_documents(category);
CREATE INDEX idx_normativa_subcategory ON normativa_documents(subcategory);
CREATE INDEX idx_normativa_source ON normativa_documents(source);
CREATE INDEX idx_normativa_effective_date ON normativa_documents(effective_date);
CREATE INDEX idx_normativa_vigente ON normativa_documents(expiration_date) 
    WHERE expiration_date IS NULL OR expiration_date > CURRENT_DATE;

-- ============================================================
-- 2. TABLA DE CHUNKS CON EMBEDDINGS (VECTOR SEARCH)
-- ============================================================

CREATE TABLE IF NOT EXISTS normativa_chunks (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    document_id UUID NOT NULL REFERENCES normativa_documents(id) ON DELETE CASCADE,
    
    -- Posición del chunk
    chunk_index INT NOT NULL,
    
    -- Contenido
    chunk_text TEXT NOT NULL,
    article_reference VARCHAR(100),       -- 'Art. 92.1', 'DA 5ª', 'Apartado 3.b)', etc.
    section_title VARCHAR(255),
    
    -- Vector embedding (OpenAI ada-002 = 1536 dimensiones)
    embedding vector(1536),
    
    -- Metadata adicional para filtrado
    metadata JSONB DEFAULT '{}',
    
    -- Auditoría
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- Constraint único para evitar duplicados
    CONSTRAINT unique_document_chunk UNIQUE (document_id, chunk_index)
);

-- Índice para búsqueda vectorial (usando cosine similarity)
CREATE INDEX idx_chunks_embedding ON normativa_chunks 
    USING ivfflat (embedding vector_cosine_ops) WITH (lists = 100);

-- Índice para filtrar por documento
CREATE INDEX idx_chunks_document ON normativa_chunks(document_id);

-- ============================================================
-- 3. TABLA DE FAQS VERIFICADAS
-- ============================================================

CREATE TABLE IF NOT EXISTS normativa_faqs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    
    -- Categorización
    category VARCHAR(20) NOT NULL,
    subcategory VARCHAR(50),
    
    -- Contenido
    question TEXT NOT NULL,
    answer TEXT NOT NULL,
    source_references TEXT[],             -- Array de referencias normativas
    
    -- Vector para búsqueda semántica
    embedding vector(1536),
    
    -- Verificación
    last_verified TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    verified_by VARCHAR(100),
    verification_source TEXT,             -- Enlace o referencia de verificación
    
    -- Popularidad
    usage_count INT DEFAULT 0,
    helpful_votes INT DEFAULT 0,
    
    -- Auditoría
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT valid_faq_category CHECK (category IN ('TAX', 'SS', 'SUBVENCION'))
);

CREATE INDEX idx_faqs_category ON normativa_faqs(category);
CREATE INDEX idx_faqs_embedding ON normativa_faqs 
    USING ivfflat (embedding vector_cosine_ops) WITH (lists = 50);

-- ============================================================
-- 4. TABLA DE ACTUALIZACIONES NORMATIVAS
-- ============================================================

CREATE TABLE IF NOT EXISTS normativa_updates (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    
    -- Referencia al documento
    document_id UUID REFERENCES normativa_documents(id) ON DELETE SET NULL,
    
    -- Tipo de cambio
    change_type VARCHAR(20) NOT NULL,     -- 'NEW', 'MODIFIED', 'DEPRECATED', 'CORRECTED'
    change_description TEXT,
    
    -- Fuente de la actualización
    source_url TEXT,
    boe_reference VARCHAR(100),           -- Referencia BOE/BOJA si aplica
    
    -- Estado
    detected_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    applied_at TIMESTAMP,
    notified BOOLEAN DEFAULT FALSE,
    notification_sent_at TIMESTAMP,
    
    -- Auditoría
    created_by VARCHAR(100),
    
    CONSTRAINT valid_change_type CHECK (change_type IN ('NEW', 'MODIFIED', 'DEPRECATED', 'CORRECTED'))
);

CREATE INDEX idx_updates_document ON normativa_updates(document_id);
CREATE INDEX idx_updates_pending ON normativa_updates(applied_at) WHERE applied_at IS NULL;

-- ============================================================
-- 5. TABLA DE TRIGGERS DE DETECCIÓN DE MODOS
-- ============================================================

CREATE TABLE IF NOT EXISTS copilot_mode_triggers (
    id SERIAL PRIMARY KEY,
    
    -- Modo asociado
    mode VARCHAR(30) NOT NULL,
    
    -- Trigger
    trigger_word VARCHAR(100) NOT NULL,
    weight INT DEFAULT 1,                 -- Peso para puntuación
    
    -- Metadata
    language VARCHAR(5) DEFAULT 'es',
    is_active BOOLEAN DEFAULT TRUE,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT valid_mode CHECK (mode IN (
        'COACH_EMOCIONAL',
        'CONSULTOR_TACTICO',
        'SPARRING_PARTNER',
        'CFO_SINTETICO',
        'ABOGADO_DIABLO',
        'TAX_EXPERT',
        'SS_EXPERT'
    ))
);

CREATE INDEX idx_triggers_mode ON copilot_mode_triggers(mode);
CREATE INDEX idx_triggers_word ON copilot_mode_triggers(trigger_word);

-- ============================================================
-- 6. TABLA DE MÉTRICAS DEL COPILOTO
-- ============================================================

CREATE TABLE IF NOT EXISTS copilot_metrics (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    
    -- Contexto
    user_id UUID,
    session_id VARCHAR(100),
    
    -- Detección de modo
    mode_detected VARCHAR(30) NOT NULL,
    mode_confidence DECIMAL(5,4),
    matched_triggers TEXT[],
    
    -- Proveedor
    provider_used VARCHAR(50) NOT NULL,
    used_fallback BOOLEAN DEFAULT FALSE,
    
    -- RAG
    rag_used BOOLEAN DEFAULT FALSE,
    rag_docs_retrieved INT DEFAULT 0,
    rag_avg_score DECIMAL(5,4),
    
    -- Rendimiento
    latency_ms INT,
    tokens_input INT,
    tokens_output INT,
    tokens_total INT,
    estimated_cost DECIMAL(10,6),
    
    -- Cache
    cache_hit BOOLEAN DEFAULT FALSE,
    
    -- Resultado
    response_length INT,
    has_citations BOOLEAN DEFAULT FALSE,
    
    -- Auditoría
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_metrics_user ON copilot_metrics(user_id);
CREATE INDEX idx_metrics_mode ON copilot_metrics(mode_detected);
CREATE INDEX idx_metrics_provider ON copilot_metrics(provider_used);
CREATE INDEX idx_metrics_date ON copilot_metrics(created_at);

-- ============================================================
-- 7. FUNCIONES ÚTILES
-- ============================================================

-- Función para buscar chunks similares
CREATE OR REPLACE FUNCTION search_normativa_chunks(
    query_embedding vector(1536),
    p_category VARCHAR(20),
    p_top_k INT DEFAULT 10,
    p_min_score DECIMAL DEFAULT 0.7
)
RETURNS TABLE (
    chunk_id UUID,
    document_id UUID,
    chunk_text TEXT,
    article_reference VARCHAR(100),
    source VARCHAR(50),
    title TEXT,
    last_verified TIMESTAMP,
    similarity DECIMAL
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        c.id AS chunk_id,
        c.document_id,
        c.chunk_text,
        c.article_reference,
        d.source,
        d.title,
        d.last_verified,
        (1 - (c.embedding <=> query_embedding))::DECIMAL AS similarity
    FROM normativa_chunks c
    JOIN normativa_documents d ON c.document_id = d.id
    WHERE d.category = p_category
      AND (d.expiration_date IS NULL OR d.expiration_date > CURRENT_DATE)
      AND (1 - (c.embedding <=> query_embedding)) >= p_min_score
    ORDER BY c.embedding <=> query_embedding
    LIMIT p_top_k;
END;
$$ LANGUAGE plpgsql;

-- Función para buscar FAQs similares
CREATE OR REPLACE FUNCTION search_normativa_faqs(
    query_embedding vector(1536),
    p_category VARCHAR(20),
    p_top_k INT DEFAULT 5,
    p_min_score DECIMAL DEFAULT 0.75
)
RETURNS TABLE (
    faq_id UUID,
    question TEXT,
    answer TEXT,
    source_references TEXT[],
    last_verified TIMESTAMP,
    similarity DECIMAL
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        f.id AS faq_id,
        f.question,
        f.answer,
        f.source_references,
        f.last_verified,
        (1 - (f.embedding <=> query_embedding))::DECIMAL AS similarity
    FROM normativa_faqs f
    WHERE f.category = p_category
      AND (1 - (f.embedding <=> query_embedding)) >= p_min_score
    ORDER BY f.embedding <=> query_embedding
    LIMIT p_top_k;
END;
$$ LANGUAGE plpgsql;

-- Función para obtener estadísticas del índice
CREATE OR REPLACE FUNCTION get_normativa_stats()
RETURNS TABLE (
    category VARCHAR(20),
    document_count BIGINT,
    chunk_count BIGINT,
    faq_count BIGINT,
    last_update TIMESTAMP
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        d.category,
        COUNT(DISTINCT d.id) AS document_count,
        COUNT(DISTINCT c.id) AS chunk_count,
        (SELECT COUNT(*) FROM normativa_faqs f WHERE f.category = d.category) AS faq_count,
        MAX(d.updated_at) AS last_update
    FROM normativa_documents d
    LEFT JOIN normativa_chunks c ON d.id = c.document_id
    GROUP BY d.category;
END;
$$ LANGUAGE plpgsql;

-- ============================================================
-- 8. DATOS INICIALES: TRIGGERS DE MODO
-- ============================================================

-- Triggers para TAX_EXPERT
INSERT INTO copilot_mode_triggers (mode, trigger_word, weight) VALUES
('TAX_EXPERT', 'hacienda', 12),
('TAX_EXPERT', 'iva', 12),
('TAX_EXPERT', 'irpf', 12),
('TAX_EXPERT', 'modelo 303', 15),
('TAX_EXPERT', 'modelo 130', 15),
('TAX_EXPERT', 'modelo 131', 15),
('TAX_EXPERT', 'modelo 036', 15),
('TAX_EXPERT', 'modelo 037', 15),
('TAX_EXPERT', 'declaración', 8),
('TAX_EXPERT', 'factura', 8),
('TAX_EXPERT', 'facturación', 9),
('TAX_EXPERT', 'impuestos', 10),
('TAX_EXPERT', 'fiscal', 10),
('TAX_EXPERT', 'tributario', 10),
('TAX_EXPERT', 'aeat', 12),
('TAX_EXPERT', 'agencia tributaria', 12),
('TAX_EXPERT', 'epígrafe', 10),
('TAX_EXPERT', 'iae', 10),
('TAX_EXPERT', 'trimestre', 6),
('TAX_EXPERT', 'deducir', 8),
('TAX_EXPERT', 'deducible', 8),
('TAX_EXPERT', 'gastos deducibles', 12),
('TAX_EXPERT', 'verifactu', 12),
('TAX_EXPERT', 'retención', 9),
('TAX_EXPERT', 'base imponible', 10),
('TAX_EXPERT', 'estimación directa', 12),
('TAX_EXPERT', 'estimación objetiva', 12),
('TAX_EXPERT', 'módulos', 9);

-- Triggers para SS_EXPERT
INSERT INTO copilot_mode_triggers (mode, trigger_word, weight) VALUES
('SS_EXPERT', 'autónomo', 10),
('SS_EXPERT', 'autónomos', 10),
('SS_EXPERT', 'cuota', 9),
('SS_EXPERT', 'reta', 12),
('SS_EXPERT', 'tarifa plana', 15),
('SS_EXPERT', 'seguridad social', 12),
('SS_EXPERT', 'cotización', 10),
('SS_EXPERT', 'cotizar', 9),
('SS_EXPERT', 'darme de alta', 12),
('SS_EXPERT', 'darse de alta', 12),
('SS_EXPERT', 'baja autónomo', 12),
('SS_EXPERT', 'pluriactividad', 12),
('SS_EXPERT', 'base de cotización', 12),
('SS_EXPERT', '80 euros', 12),
('SS_EXPERT', 'cuota cero', 15),
('SS_EXPERT', 'bonificación', 9),
('SS_EXPERT', 'bonificaciones', 9),
('SS_EXPERT', 'incapacidad temporal', 10),
('SS_EXPERT', 'maternidad', 7),
('SS_EXPERT', 'paternidad', 7),
('SS_EXPERT', 'cese actividad', 10),
('SS_EXPERT', 'paro autónomo', 12),
('SS_EXPERT', 'tgss', 12),
('SS_EXPERT', 'tesorería', 8);

-- ============================================================
-- 9. DATOS INICIALES: DOCUMENTOS NORMATIVOS BASE
-- ============================================================

-- Normativa Fiscal
INSERT INTO normativa_documents (source, category, subcategory, title, effective_date, description) VALUES
('BOE', 'TAX', 'IRPF', 'Ley 35/2006, de 28 de noviembre, del Impuesto sobre la Renta de las Personas Físicas', '2007-01-01', 'Ley reguladora del IRPF en España'),
('BOE', 'TAX', 'IVA', 'Ley 37/1992, de 28 de diciembre, del Impuesto sobre el Valor Añadido', '1993-01-01', 'Ley reguladora del IVA en España'),
('AEAT', 'TAX', 'IVA', 'Modelo 303 - Autoliquidación IVA trimestral', '2023-01-01', 'Instrucciones para la presentación del modelo 303'),
('AEAT', 'TAX', 'IRPF', 'Modelo 130 - Pago fraccionado IRPF (Estimación Directa)', '2023-01-01', 'Pago fraccionado para autónomos en estimación directa'),
('AEAT', 'TAX', 'IRPF', 'Modelo 131 - Pago fraccionado IRPF (Estimación Objetiva)', '2023-01-01', 'Pago fraccionado para autónomos en módulos'),
('AEAT', 'TAX', 'CENSAL', 'Modelo 036 - Declaración censal completa', '2023-01-01', 'Alta, modificación y baja en el censo de empresarios'),
('AEAT', 'TAX', 'CENSAL', 'Modelo 037 - Declaración censal simplificada', '2023-01-01', 'Versión simplificada para autónomos'),
('AEAT', 'TAX', 'DEDUCIBLES', 'Guía de gastos deducibles para autónomos', '2024-01-01', 'Criterios de deducibilidad de gastos en actividad económica'),
('BOE', 'TAX', 'FACTURACION', 'RD 1619/2012 Reglamento de facturación', '2013-01-01', 'Requisitos legales de las facturas');

-- Normativa Seguridad Social
INSERT INTO normativa_documents (source, category, subcategory, title, effective_date, description) VALUES
('BOE', 'SS', 'RETA', 'RD Legislativo 8/2015 - Ley General de la Seguridad Social (RETA)', '2015-10-31', 'Régimen Especial de Trabajadores Autónomos'),
('BOE', 'SS', 'RETA', 'Ley 20/2007 - Estatuto del Trabajo Autónomo', '2007-07-12', 'Marco legal del trabajo autónomo en España'),
('BOE', 'SS', 'COTIZACION', 'Orden de cotización 2025', '2025-01-01', 'Bases y tipos de cotización para el año 2025'),
('TGSS', 'SS', 'COTIZACION', 'Sistema de cotización por ingresos reales', '2023-01-01', 'Nuevo sistema de cotización progresivo'),
('BOE', 'SS', 'TARIFA_PLANA', 'RDL 13/2022 - Nueva tarifa plana autónomos', '2023-01-01', 'Cuota reducida de 80€ durante 12 meses'),
('TGSS', 'SS', 'PRESTACIONES', 'Cese de actividad para autónomos', '2023-01-01', 'Requisitos y cuantía del cese de actividad'),
('TGSS', 'SS', 'PRESTACIONES', 'Incapacidad temporal autónomos', '2023-01-01', 'Cobertura IT para trabajadores autónomos'),
('SEPE', 'SS', 'COMPATIBILIDAD', 'Compatibilidad prestación por desempleo y trabajo autónomo', '2023-01-01', 'Opciones de capitalización y compatibilización'),
('MITES', 'SS', 'COMPATIBILIDAD', 'Compatibilidad IMV y trabajo autónomo', '2023-01-01', 'Ingreso Mínimo Vital compatible con actividad económica');

-- Subvenciones Andalucía
INSERT INTO normativa_documents (source, category, subcategory, title, effective_date, description) VALUES
('BOJA', 'SUBVENCION', 'AUTONOMOS', 'PIIL - Bases Reguladoras Proyectos Integrales', '2023-01-01', 'Bases reguladoras del programa de inserción laboral'),
('BOJA', 'SUBVENCION', 'CUOTA_CERO', 'Línea 1 - Bonificación Cuota Cero', '2025-01-01', '100% bonificación cuota SS durante 24 meses'),
('BOJA', 'SUBVENCION', 'INICIO_ACTIVIDAD', 'Línea 2 - Ayuda Inicio Actividad', '2025-01-01', 'Ayuda directa 3.800€-5.600€ según colectivo'),
('SAE', 'SUBVENCION', 'CONVOCATORIA', 'Convocatoria Proyectos Integrales 2025', '2025-11-19', 'Convocatoria específica para 2025');

-- ============================================================
-- 10. DATOS INICIALES: FAQs VERIFICADAS
-- ============================================================

INSERT INTO normativa_faqs (category, subcategory, question, answer, source_references, verified_by) VALUES
('SS', 'TARIFA_PLANA', 
 '¿Cuánto pago de cuota de autónomo con la tarifa plana?',
 'Con la tarifa plana pagas 80€/mes durante los primeros 12 meses. Si tus ingresos netos anuales son inferiores al SMI, puedes prorrogarla otros 12 meses más (total 24 meses a 80€).',
 ARRAY['RDL 13/2022', 'Art. 38 ter LETA'],
 'Verificado TGSS Enero 2025'),

('SS', 'TARIFA_PLANA',
 '¿Qué requisitos necesito para acceder a la tarifa plana?',
 'Requisitos: 1) No haber estado de alta como autónomo en los últimos 2 años (3 años si ya disfrutaste de tarifa plana antes). 2) No ser autónomo colaborador familiar. 3) No tener deudas pendientes con la Seguridad Social.',
 ARRAY['Art. 38 ter LETA', 'RDL 13/2022 Art. 1'],
 'Verificado TGSS Enero 2025'),

('SS', 'COMPATIBILIDAD',
 '¿Puedo cobrar el paro y darme de alta como autónomo?',
 'Sí, tienes tres opciones: 1) Capitalizar el 100% en pago único para inversión. 2) Capitalizar parte y cobrar el resto mensualmente como subvención de cuotas. 3) Suspender el paro hasta 60 meses y recuperarlo si cierras el negocio.',
 ARRAY['Art. 214 LGSS', 'RD 1044/1985'],
 'Verificado SEPE Enero 2025'),

('TAX', 'CENSAL',
 '¿Qué modelo debo presentar para darme de alta como autónomo en Hacienda?',
 'Debes presentar el Modelo 037 (simplificado) si eres persona física y no realizas operaciones intracomunitarias. Si necesitas declarar operaciones intracomunitarias, aplicar regímenes especiales de IVA o declarar más de un epígrafe del IAE, usa el Modelo 036.',
 ARRAY['AEAT - Modelos Censales'],
 'Verificado AEAT Enero 2025'),

('TAX', 'DEDUCIBLES',
 '¿Puedo deducirme los gastos del coche como autónomo?',
 'Solo si el vehículo se usa exclusivamente para la actividad profesional (difícil de demostrar). Para vehículos de uso mixto, puedes deducir hasta el 50% de los gastos (combustible, seguro, mantenimiento). El IVA de la compra solo es deducible al 50% máximo. Recomendación: lleva un registro de kilómetros profesionales.',
 ARRAY['Art. 29 Ley IRPF', 'Criterio DGT'],
 'Verificado AEAT Enero 2025'),

('SUBVENCION', 'CUOTA_CERO',
 '¿Qué es la Cuota Cero de Andalucía?',
 'Es una subvención de la Junta de Andalucía que cubre el 100% de tu cuota de autónomo durante 24 meses. Es compatible con la tarifa plana estatal: pagas 80€ de tarifa plana y la Junta te devuelve esos 80€. Resultado: coste 0€ de cuota durante 2 años.',
 ARRAY['PIIL BBRR Línea 1', 'Orden 30/07/2025'],
 'Verificado SAE Enero 2025'),

('SUBVENCION', 'INICIO_ACTIVIDAD',
 '¿Cuánto dinero puedo recibir de la Línea 2 de ayuda al inicio de actividad?',
 'Depende de tu colectivo: General (3.800€), Mujer <35 años u hombre <30 años (5.000€), Persona con discapacidad ≥33% o víctima violencia (5.600€). Incremento adicional si resides en municipio <10.000 habitantes (+200€ a +1.200€). Plazo: solicitar en los 2 meses siguientes al alta RETA.',
 ARRAY['PIIL BBRR Línea 2', 'Art. 8 Orden 30/07/2025'],
 'Verificado SAE Enero 2025');

-- ============================================================
-- 11. TRIGGER PARA ACTUALIZAR updated_at
-- ============================================================

CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_normativa_documents_updated_at
    BEFORE UPDATE ON normativa_documents
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_normativa_faqs_updated_at
    BEFORE UPDATE ON normativa_faqs
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- ============================================================
-- FIN DEL ESQUEMA
-- ============================================================

COMMENT ON TABLE normativa_documents IS 'Documentos normativos para el sistema RAG del Copiloto';
COMMENT ON TABLE normativa_chunks IS 'Chunks de texto con embeddings para búsqueda vectorial';
COMMENT ON TABLE normativa_faqs IS 'Preguntas frecuentes verificadas para respuestas rápidas';
COMMENT ON TABLE copilot_mode_triggers IS 'Palabras clave para detección automática de modos';
COMMENT ON TABLE copilot_metrics IS 'Métricas de uso del Copiloto para análisis';
